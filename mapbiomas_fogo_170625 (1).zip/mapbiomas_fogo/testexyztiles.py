import requests  # Importa a biblioteca requests para fazer requisições HTTP

url = "https://staging.api.mapbiomas.org/api/v1/brazil/maps/fire_annual"  # Define a URL da API

params = {
    "territoryIds": "10001",         # string, não lista
    "pixelValues": "-1",             # string, não lista
    "bboxSize": "256",
    "year": 2023,
    "legend": "fire_annual_by_total_burned"
}

response = requests.get(url, params=params)  # Faz uma requisição GET para a URL com os parâmetros definidos
print(response.text)